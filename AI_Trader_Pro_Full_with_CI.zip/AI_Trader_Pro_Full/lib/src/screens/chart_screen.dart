
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../services/signal_engine.dart';
import '../services/signal_store.dart';
import '../models/signal.dart';
import '../services/ai_strictness.dart';
import '../services/news_filter.dart';
import '../services/options_helper.dart';
import '../services/backtester.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});
  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late WebViewController _controller;
  String symbol = "AAPL";
  String timeframe = "60";
  List<Signal> signals = [];
  BacktesterResult? lastBacktest;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset("assets/html/tradingview_overlay.html");
    WidgetsBinding.instance.addPostFrameCallback((_){
      final app = context.read<AppState>();
      symbol = app.defaultSymbol;
      timeframe = app.defaultTimeframe;
      _loadSignals();
    });
  }

  Future<void> _loadSignals() async {
    final saved = await SignalStore.load(symbol, timeframe);
    if (saved.isNotEmpty){ signals = saved; setState((){}); return; }
    await _regenerateSignals();
  }

  Future<void> _regenerateSignals() async {
    final app = context.read<AppState>();
    final fresh = await SignalEngine.generate(symbol, timeframe, count: 120);
    final filtered = AIStrictness.filter(fresh, app.strictness);
    if (app.newsFilter){
      final risk = await NewsFilter.sessionRisk(symbol);
      // If hot news, keep only top half
      signals = risk>50 ? filtered.take((filtered.length/2).floor()).toList() : filtered;
    } else {
      signals = filtered;
    }
    await SignalStore.save(symbol, timeframe, signals);
    setState((){});
  }

  Future<void> _overlaySignals() async {
    final payload = jsonEncode({
      "type":"signals",
      "symbol": symbol,
      "timeframe": timeframe,
      "signals": signals.map((s)=>s.toJson()).toList(),
    });
    await _controller.runJavaScript("window.applyAISignals($payload);");
  }

  Future<void> _runBacktest() async {
    lastBacktest = await Backtester.run(signals);
    if (mounted) setState((){});
    if (lastBacktest!=null){
      final r = lastBacktest!;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
        Text("Backtest: trades=${r.trades}, winRate=${r.winRate.toStringAsFixed(1)}%, PnL=${r.netPnl.toStringAsFixed(2)}")));
    }
  }

  Future<void> _suggestOption() async {
    final first = signals.isNotEmpty ? signals.last : null;
    final side = first?.side ?? "BUY";
    final m = await OptionsHelper.suggest(symbol, side);
    final msg = "Expiry: ${m['expiry']}\nStrike: ${m['strike']}\nContract: ${m['contract']}\nRR: ${m['rr']}";
    // show result
    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: TextField(
              decoration: const InputDecoration(labelText: "Symbol", border: OutlineInputBorder()),
              controller: TextEditingController(text: symbol),
              onSubmitted: (v) async { symbol=v.toUpperCase(); await _loadSignals(); },
            )),
            const SizedBox(width: 8),
            DropdownButton<String>(value: timeframe, items: const [
              DropdownMenuItem(value: "1", child: Text("1m")),
              DropdownMenuItem(value: "5", child: Text("5m")),
              DropdownMenuItem(value: "15", child: Text("15m")),
              DropdownMenuItem(value: "60", child: Text("1H")),
              DropdownMenuItem(value: "240", child: Text("4H")),
              DropdownMenuItem(value: "D", child: Text("1D")),
            ], onChanged: (v) async { if (v!=null){ timeframe=v; await _loadSignals(); } }),
            const SizedBox(width: 8),
            SwitchListTile(
              value: app.coach, onChanged: app.setCoach, title: const Text("Coach", style: TextStyle(fontSize: 12)),
              contentPadding: EdgeInsets.zero,
            ),
          ]),
        ),
        Expanded(child: WebViewWidget(controller: _controller)),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            ElevatedButton(onPressed: _overlaySignals, child: const Text("Overlay Signals")),
            const SizedBox(width: 8),
            OutlinedButton(onPressed: _regenerateSignals, child: const Text("Regenerate")),
            const SizedBox(width: 8),
            OutlinedButton(onPressed: _runBacktest, child: const Text("Backtest")),
            const SizedBox(width: 8),
            OutlinedButton(onPressed: _suggestOption, child: const Text("Options Helper")),
          ]),
        ),
      ],
    );
  }
}
