
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text("General", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        ListTile(
          title: const Text("Default Symbol"),
          subtitle: Text(app.defaultSymbol),
          trailing: SizedBox(width: 120, child: TextField(
            decoration: const InputDecoration(border: OutlineInputBorder()),
            onSubmitted: app.setDefaultSymbol,
          )),
        ),
        ListTile(
          title: const Text("Default Timeframe"),
          subtitle: Text(app.defaultTimeframe),
          trailing: DropdownButton<String>(
            value: app.defaultTimeframe,
            onChanged: (v){ if (v!=null) app.setDefaultTimeframe(v); },
            items: const [
              DropdownMenuItem(value: "1", child: Text("1m")),
              DropdownMenuItem(value: "5", child: Text("5m")),
              DropdownMenuItem(value: "15", child: Text("15m")),
              DropdownMenuItem(value: "60", child: Text("1H")),
              DropdownMenuItem(value: "240", child: Text("4H")),
              DropdownMenuItem(value: "D", child: Text("1D")),
            ],
          ),
        ),
        const Divider(),
        const Text("Trading", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SwitchListTile(title: const Text("Auto-Trade (stub)"), value: app.autoTrade, onChanged: app.setAutoTrade),
        ListTile(
          title: const Text("Risk Strictness"),
          subtitle: Text(app.strictness.name),
          trailing: DropdownButton<Strictness>(
            value: app.strictness,
            onChanged: (v){ if (v!=null) app.setStrictness(v); },
            items: const [
              DropdownMenuItem(value: Strictness.safe, child: Text("Safe")),
              DropdownMenuItem(value: Strictness.balanced, child: Text("Balanced")),
              DropdownMenuItem(value: Strictness.risk, child: Text("Risk")),
            ],
          ),
        ),
        ListTile(
          title: const Text("Learning Mode"),
          subtitle: Text(app.learning.name),
          trailing: DropdownButton<LearningMode>(
            value: app.learning,
            onChanged: (v){ if (v!=null) app.setLearning(v); },
            items: const [
              DropdownMenuItem(value: LearningMode.off, child: Text("Off")),
              DropdownMenuItem(value: LearningMode.ask, child: Text("Ask")),
              DropdownMenuItem(value: LearningMode.auto, child: Text("Auto")),
            ],
          ),
        ),
        const Divider(),
        const Text("Filters & Tools", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SwitchListTile(title: const Text("News Impact Filter"), value: app.newsFilter, onChanged: app.setNewsFilter),
        SwitchListTile(title: const Text("Heatmaps"), value: app.heatmaps, onChanged: app.setHeatmaps),
        SwitchListTile(title: const Text("Options Helper"), value: app.optionsHelper, onChanged: app.setOptionsHelper),
        SwitchListTile(title: const Text("Backtester"), value: app.backtester, onChanged: app.setBacktester),
        SwitchListTile(title: const Text("Plugin Store"), value: app.pluginStore, onChanged: app.setPluginStore),
        const SizedBox(height: 24),
        const Text("Note: Auto-Trade & data providers are stubs. Plug your broker/data to go live."),
      ],
    );
  }
}
