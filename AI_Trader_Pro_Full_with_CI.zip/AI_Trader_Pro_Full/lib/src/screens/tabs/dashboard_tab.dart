
import 'package:flutter/material.dart';
import '../../services/backtester.dart';
import '../../services/signal_store.dart';
import '../../services/signal_engine.dart';
import '../../models/signal.dart';

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});
  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  String symbol = "AAPL";
  String timeframe = "60";
  Map<String,dynamic>? result;

  Future<void> _run() async {
    var sigs = await SignalStore.load(symbol, timeframe);
    if (sigs.isEmpty){
      sigs = await SignalEngine.generate(symbol, timeframe);
    }
    result = await Backtester.run(sigs);
    if (mounted) setState((){});
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text("Performance Dashboard", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: TextField(
              decoration: const InputDecoration(labelText: "Symbol", border: OutlineInputBorder()),
              onSubmitted: (v)=> symbol=v.toUpperCase(),
            )),
            const SizedBox(width: 8),
            DropdownButton<String>(
              value: timeframe,
              items: const [
                DropdownMenuItem(value: "1", child: Text("1m")),
                DropdownMenuItem(value: "5", child: Text("5m")),
                DropdownMenuItem(value: "15", child: Text("15m")),
                DropdownMenuItem(value: "60", child: Text("1H")),
                DropdownMenuItem(value: "240", child: Text("4H")),
                DropdownMenuItem(value: "D", child: Text("1D")),
              ],
              onChanged: (v){ if (v!=null) setState(()=> timeframe=v); },
            ),
            const SizedBox(width: 8),
            ElevatedButton(onPressed: _run, child: const Text("Backtest")),
          ],
        ),
        const SizedBox(height: 16),
        if (result!=null) Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Win Rate: ${result!['winRate'].toStringAsFixed(1)}%"),
                Text("Wins: ${result!['wins']}"),
                Text("Losses: ${result!['losses']}"),
                Text("Total: ${result!['total']}"),
              ],
            ),
          ),
        )
      ],
    );
  }
}
