
import 'dart:math';

class Indicators {
  // Simple moving average
  static List<double> sma(List<double> data, int period){
    final out = <double>[];
    double sum = 0;
    for (int i=0;i<data.length;i++){
      sum += data[i];
      if (i>=period) sum -= data[i-period];
      if (i>=period-1) out.add(sum/period);
      else out.add(double.nan);
    }
    return out;
  }

  // RSI (wilders)
  static List<double> rsi(List<double> data, int period){
    final out = List<double>.filled(data.length, double.nan);
    double gain = 0, loss = 0;
    for (int i=1;i<=period;i++){
      final diff = data[i]-data[i-1];
      if (diff>=0) gain += diff; else loss -= diff;
    }
    double rs = loss==0 ? 0 : gain/loss;
    out[period] = 100 - (100/(1+rs));
    for (int i=period+1;i<data.length;i++){
      final diff = data[i]-data[i-1];
      final g = diff>0 ? diff : 0;
      final l = diff<0 ? -diff : 0;
      gain = (gain*(period-1)+g)/period;
      loss = (loss*(period-1)+l)/period;
      rs = loss==0 ? 0 : gain/loss;
      out[i] = 100 - (100/(1+rs));
    }
    return out;
  }

  // ATR (simplified)
  static List<double> atr(List<double> high, List<double> low, List<double> close, int period){
    final tr = <double>[];
    for (int i=0;i<close.length;i++){
      final prev = i==0 ? close[0] : close[i-1];
      final a = high[i]-low[i];
      final b = (high[i]-prev).abs();
      final c = (low[i]-prev).abs();
      tr.add([a,b,c].reduce(max));
    }
    final out = <double>[];
    double sum = 0;
    for (int i=0;i<tr.length;i++){
      sum += tr[i];
      if (i>=period) sum -= tr[i-period];
      if (i>=period-1) out.add(sum/period); else out.add(double.nan);
    }
    return out;
  }
}
