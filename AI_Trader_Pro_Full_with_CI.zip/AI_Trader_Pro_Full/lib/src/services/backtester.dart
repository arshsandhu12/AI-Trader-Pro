
import 'dart:math';
import '../models/signal.dart';

class Backtester {
  // Simulates win rate using saved signals with simple RR model.
  static Future<Map<String, dynamic>> run(List<Signal> signals) async {
    int wins = 0, losses = 0;
    for (final s in signals){
      final rr = (s.tp - s.entry).abs() / (s.entry - s.sl).abs();
      // crude probability tied to score and rr
      final p = (s.score/100.0)*0.6 + (min(rr,3.0)/3.0)*0.4;
      final r = Random(s.id.hashCode).nextDouble();
      if (r < p) wins++; else losses++;
    }
    final total = (wins+losses).clamp(1, 999999);
    return {
      'wins': wins,
      'losses': losses,
      'winRate': wins*100.0/total,
      'total': total,
    };
  }
}
