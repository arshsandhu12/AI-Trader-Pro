
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Storage {
  static Future<void> setJson(String key, Object value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(value));
  }
  static Future<Map<String,dynamic>?> getJson(String key) async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(key);
    if (s==null) return null;
    return (jsonDecode(s) as Map).cast<String,dynamic>();
  }
  static Future<void> setList(String key, List list) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(list));
  }
  static Future<List<dynamic>> getList(String key) async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(key);
    if (s==null) return [];
    return (jsonDecode(s) as List);
  }
}
