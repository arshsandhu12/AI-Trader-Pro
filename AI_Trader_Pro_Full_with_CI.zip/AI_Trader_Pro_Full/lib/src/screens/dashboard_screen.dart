
import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    // Placeholder stats (hook into real PnL + win rate later)
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        Text("Performance Dashboard", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text("• Win rate: (placeholder)"),
        Text("• Avg RR: (placeholder)"),
        Text("• Net P&L: (placeholder)"),
        SizedBox(height: 16),
        Text("Graphs will appear here when real trade data is connected."),
      ],
    );
  }
}
