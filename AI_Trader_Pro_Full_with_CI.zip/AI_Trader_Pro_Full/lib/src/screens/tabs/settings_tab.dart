
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/app_state.dart';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text("Settings", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ListTile(
          title: const Text("Trade Mode"),
          trailing: DropdownButton<Mode>(
            value: app.mode,
            onChanged: (v){ if (v!=null) app.setMode(v); },
            items: const [
              DropdownMenuItem(value: Mode.day, child: Text("Day")),
              DropdownMenuItem(value: Mode.swing, child: Text("Swing")),
              DropdownMenuItem(value: Mode.options, child: Text("Options")),
            ],
          ),
        ),
        ListTile(
          title: const Text("Strictness"),
          trailing: DropdownButton<Strictness>(
            value: app.strictness,
            onChanged: (v){ if (v!=null) app.setStrictness(v); },
            items: const [
              DropdownMenuItem(value: Strictness.safe, child: Text("Safe")),
              DropdownMenuItem(value: Strictness.balanced, child: Text("Balanced")),
              DropdownMenuItem(value: Strictness.risk, child: Text("Risk")),
            ],
          ),
        ),
        ListTile(
          title: const Text("AI Apply"),
          subtitle: const Text("Off / Ask / Auto"),
          trailing: DropdownButton<AiApply>(
            value: app.aiApply,
            onChanged: (v){ if (v!=null) app.setAiApply(v); },
            items: const [
              DropdownMenuItem(value: AiApply.off, child: Text("Off")),
              DropdownMenuItem(value: AiApply.ask, child: Text("Ask")),
              DropdownMenuItem(value: AiApply.auto, child: Text("Auto")),
            ],
          ),
        ),
        SwitchListTile(title: const Text("Auto-Trade"), value: app.autoTrade, onChanged: app.setAutoTrade),
        SwitchListTile(title: const Text("Coach Mode"), value: app.coachMode, onChanged: app.setCoachMode),
        SwitchListTile(title: const Text("Learning Hub"), value: app.learningHub, onChanged: app.setLearningHub),
        SwitchListTile(title: const Text("TV Overlay"), value: app.tvOverlay, onChanged: app.setTvOverlay),
        SwitchListTile(title: const Text("Backtester Enabled"), value: app.backtesterEnabled, onChanged: app.setBacktester),
        SwitchListTile(title: const Text("Bias Auto-Update"), value: app.biasAutoUpdate, onChanged: app.setBiasAutoUpdate),
        SwitchListTile(title: const Text("AI Auto-Merge"), value: app.aiAutoMerge, onChanged: app.setAiAutoMerge),
        SwitchListTile(title: const Text("News Filter"), value: app.newsFilter, onChanged: app.setNewsFilter),
        SwitchListTile(title: const Text("Heatmap Enabled"), value: app.heatmapEnabled, onChanged: app.setHeatmap),
        SwitchListTile(title: const Text("Options Helper"), value: app.optionsHelper, onChanged: app.setOptionsHelper),
        SwitchListTile(title: const Text("Plugin Store"), value: app.pluginStoreEnabled, onChanged: app.setPluginStore),
        SwitchListTile(title: const Text("Dashboard"), value: app.dashboardEnabled, onChanged: app.setDashboard),
      ],
    );
  }
}
