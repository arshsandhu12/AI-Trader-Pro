
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class JournalEntry {
  final String id;
  final String symbol;
  final String side;
  final String note;
  final DateTime time;
  JournalEntry(this.id, this.symbol, this.side, this.note, this.time);

  Map<String,dynamic> toJson()=>{
    'id': id, 'symbol': symbol, 'side': side, 'note': note, 'time': time.toIso8601String(),
  };
  static JournalEntry fromJson(Map<String,dynamic> m)=>JournalEntry(
    m['id'], m['symbol'], m['side'], m['note'], DateTime.parse(m['time'])
  );
}

class JournalStore {
  static Future<List<JournalEntry>> all() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('journal');
    if (raw==null) return [];
    final list = (jsonDecode(raw) as List).cast<Map<String,dynamic>>();
    return list.map((m)=>JournalEntry.fromJson(m)).toList();
  }
  static Future<void> saveAll(List<JournalEntry> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('journal', jsonEncode(items.map((e)=>e.toJson()).toList()));
  }
}
