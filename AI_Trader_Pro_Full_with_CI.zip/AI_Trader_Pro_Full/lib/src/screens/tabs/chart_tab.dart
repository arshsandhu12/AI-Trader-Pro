
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../models/signal.dart';
import '../../services/signal_engine.dart';
import '../../services/signal_store.dart';
import '../../services/ai_strictness.dart';
import '../../services/news_filter.dart';
import '../../services/options_helper.dart';
import '../../services/auto_trade.dart';
import '../../state/app_state.dart';

class ChartTab extends StatefulWidget {
  const ChartTab({super.key});
  @override
  State<ChartTab> createState() => _ChartTabState();
}

class _ChartTabState extends State<ChartTab> {
  late WebViewController _controller;
  String symbol = "AAPL";
  String timeframe = "60";
  List<Signal> signals = [];
  List<Signal> filtered = [];

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset("assets/html/tradingview_overlay.html");
    _sync();
  }

  Future<void> _sync() async {
    final stored = await SignalStore.load(symbol, timeframe);
    if (stored.isEmpty){
      signals = await SignalEngine.generate(symbol, timeframe);
      await SignalStore.save(symbol, timeframe, signals);
    } else {
      signals = stored;
    }
    _applyFilter();
  }

  void _applyFilter(){
    final app = context.read<AppState>();
    filtered = AiStrictness.filter(signals, app.strictness);
    setState((){});
  }

  Future<void> _overlay() async {
    final payload = jsonEncode({
      "type":"signals",
      "symbol": symbol,
      "timeframe": timeframe,
      "signals": filtered.map((s)=>s.toJson()).toList(),
      "impact": NewsFilter.impactNow(symbol),
    });
    await _controller.runJavaScript("window.applyAISignals($payload);");
  }

  Future<void> _autoTrade() async {
    final app = context.read<AppState>();
    if (!app.autoTrade) return;
    for (final s in filtered){
      await AutoTrade.place(s);
      // In real use, persist orders here.
    }
  }

  void _suggestOptions(){
    if (filtered.isEmpty) return;
    final last = filtered.last;
    final bias = last.side=="BUY" ? "long" : "short";
    final sug = OptionsHelper.suggest(symbol, last.entry, bias: bias);
    showDialog(context: context, builder: (_)=> AlertDialog(
      title: const Text("Options Suggestion"),
      content: Text("Type: ${sug['type']}\nStrike: ${sug['strike']}\nExpiry (days): ${sug['expiryDays']}\nNote: ${sug['note']}"),
      actions: [ TextButton(onPressed: ()=>Navigator.pop(context), child: const Text("OK")) ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: "Symbol (AAPL, EURUSD, BTCUSD...)",
                    border: OutlineInputBorder(),
                  ),
                  onSubmitted: (v) async { symbol = v.toUpperCase(); await _sync(); },
                ),
              ),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: timeframe,
                items: const [
                  DropdownMenuItem(value: "1", child: Text("1m")),
                  DropdownMenuItem(value: "5", child: Text("5m")),
                  DropdownMenuItem(value: "15", child: Text("15m")),
                  DropdownMenuItem(value: "60", child: Text("1H")),
                  DropdownMenuItem(value: "240", child: Text("4H")),
                  DropdownMenuItem(value: "D", child: Text("1D")),
                ],
                onChanged: (v) async { if (v!=null){ timeframe=v; await _sync(); } },
              ),
              const SizedBox(width: 8),
              Switch(
                value: app.coachMode,
                onChanged: app.setCoachMode,
              ),
            ],
          ),
        ),
        Expanded(child: WebViewWidget(controller: _controller)),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton(onPressed: _overlay, child: const Text("Overlay Signals")),
              OutlinedButton(onPressed: () async { await _sync(); }, child: const Text("Refresh Signals")),
              OutlinedButton(onPressed: _applyFilter, child: const Text("Apply Strictness")),
              OutlinedButton(onPressed: _autoTrade, child: const Text("Auto-Trade Now")),
              OutlinedButton(onPressed: _suggestOptions, child: const Text("Options Helper")),
            ],
          ),
        ),
      ],
    );
  }
}
