
import '../models/signal.dart';

class AutoTrade {
  // Stub: connect to broker/paper API if you want. For now returns a fake order id.
  static Future<String> place(Signal s){
    return Future.value("ORDER-${s.id.hashCode}");
  }
}
