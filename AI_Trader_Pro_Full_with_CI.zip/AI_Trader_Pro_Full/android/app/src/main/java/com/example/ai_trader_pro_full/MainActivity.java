
package com.example.ai_trader_pro_full;
import io.flutter.embedding.android.FlutterActivity;
public class MainActivity extends FlutterActivity { }
