
class Signal {
  final String id;
  final String symbol;
  final String timeframe;
  final DateTime time;
  final String side; // BUY/SELL
  final double entry;
  final double sl;
  final double tp;
  final double score; // confidence 0..100
  final String reason; // short explanation

  Signal({
    required this.id,
    required this.symbol,
    required this.timeframe,
    required this.time,
    required this.side,
    required this.entry,
    required this.sl,
    required this.tp,
    required this.score,
    required this.reason,
  });

  Map<String, dynamic> toJson()=>{
    'id': id,
    'symbol': symbol,
    'timeframe': timeframe,
    'time': time.toIso8601String(),
    'side': side,
    'entry': entry,
    'sl': sl,
    'tp': tp,
    'score': score,
    'reason': reason,
  };

  static Signal fromJson(Map<String,dynamic> m)=> Signal(
    id: m['id'],
    symbol: m['symbol'],
    timeframe: m['timeframe'],
    time: DateTime.parse(m['time']),
    side: m['side'],
    entry: (m['entry'] as num).toDouble(),
    sl: (m['sl'] as num).toDouble(),
    tp: (m['tp'] as num).toDouble(),
    score: (m['score'] as num).toDouble(),
    reason: m['reason'] ?? '',
  );
}
