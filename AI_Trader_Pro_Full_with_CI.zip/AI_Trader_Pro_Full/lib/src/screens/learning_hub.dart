
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

class LearningHub extends StatefulWidget {
  const LearningHub({super.key});
  @override
  State<LearningHub> createState() => _LearningHubState();
}

class _LearningHubState extends State<LearningHub> {
  List<dynamic> lessons = [];
  @override
  void initState() {
    super.initState();
    rootBundle.loadString('assets/data/lessons.json').then((s){
      setState(()=>lessons=jsonDecode(s));
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: lessons.length,
      itemBuilder: (_,i){
        final m = lessons[i];
        return Card(
          child: ListTile(
            title: Text(m['title'] ?? 'Lesson'),
            subtitle: Text(m['body'] ?? ''),
          ),
        );
      },
    );
  }
}
