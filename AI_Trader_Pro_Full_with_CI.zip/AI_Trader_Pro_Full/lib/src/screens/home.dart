
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import 'tabs/chart_tab.dart';
import 'tabs/learn_tab.dart';
import 'tabs/journal_tab.dart';
import 'tabs/dashboard_tab.dart';
import 'tabs/settings_tab.dart';
import 'tabs/store_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int idx = 0;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final pages = [
      const ChartTab(),
      const DashboardTab(),
      const LearnTab(),
      const JournalTab(),
      if (app.pluginStoreEnabled) const StoreTab(),
      const SettingsTab(),
    ];
    final items = [
      const NavigationDestination(icon: Icon(Icons.show_chart), label: 'Chart'),
      const NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Dashboard'),
      const NavigationDestination(icon: Icon(Icons.school), label: 'Learn'),
      const NavigationDestination(icon: Icon(Icons.book_outlined), label: 'Journal'),
      if (app.pluginStoreEnabled) const NavigationDestination(icon: Icon(Icons.extension), label: 'Store'),
      const NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('AI Trader Pro')),
      body: pages[idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (v)=>setState(()=>idx=v),
        destinations: items,
      ),
    );
  }
}
