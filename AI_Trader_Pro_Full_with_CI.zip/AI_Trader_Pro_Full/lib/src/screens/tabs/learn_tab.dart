
import 'package:flutter/material.dart';

class LearnTab extends StatelessWidget {
  const LearnTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        Text("Learning Hub", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        Text("• ICT concepts: Order Blocks, FVGs, Liquidity sweeps, Quarterly theory."),
        Text("• Strictness reduces signals to higher-confluence setups."),
        Text("• News Impact Meter: avoid trading right before/after high-impact hours."),
        Text("• Signals are saved; you can re-overlay them anytime."),
      ],
    );
  }
}
