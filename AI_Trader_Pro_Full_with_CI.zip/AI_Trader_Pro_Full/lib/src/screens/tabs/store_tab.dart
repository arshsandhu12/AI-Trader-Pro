
import 'package:flutter/material.dart';

class StoreTab extends StatelessWidget {
  const StoreTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text("Strategy Store", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _card("ICT Core", "Win rate (sim): 62-68%", true),
        _card("Order Flow Filter", "Adds volume/flow confluence", false),
        _card("Quarterly Theory Bias", "Auto higher-timeframe bias", false),
      ],
    );
  }

  Widget _card(String title, String subtitle, bool installed){
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: ElevatedButton(
          onPressed: (){},
          child: Text(installed? "Installed" : "Install"),
        ),
      ),
    );
  }
}
