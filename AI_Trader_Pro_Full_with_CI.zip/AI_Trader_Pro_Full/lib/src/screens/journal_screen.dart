
import 'package:flutter/material.dart';
import '../services/journal_store.dart';

class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});
  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  List<JournalEntry> items = [];
  final noteCtrl = TextEditingController();
  String symbol = "AAPL";
  String side = "BUY";

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await JournalStore.all();
    setState((){});
  }

  Future<void> _add() async {
    final e = JournalEntry(DateTime.now().millisecondsSinceEpoch.toString(), symbol, side, noteCtrl.text, DateTime.now());
    items.insert(0, e);
    await JournalStore.saveAll(items);
    noteCtrl.clear();
    if (mounted) setState((){});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(child: TextField(decoration: const InputDecoration(labelText: "Symbol", border: OutlineInputBorder()), onSubmitted: (v)=>symbol=v.toUpperCase())),
              const SizedBox(width: 8),
              DropdownButton<String>(value: side, items: const [
                DropdownMenuItem(value: "BUY", child: Text("BUY")),
                DropdownMenuItem(value: "SELL", child: Text("SELL")),
              ], onChanged: (v){ if (v!=null) setState(()=>side=v); }),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: "Note", border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            ElevatedButton(onPressed: _add, child: const Text("Add")),
          ]),
        ),
        Expanded(child: ListView.builder(
          itemCount: items.length,
          itemBuilder: (_,i){
            final e = items[i];
            return ListTile(
              title: Text("${e.symbol} • ${e.side}"),
              subtitle: Text(e.note),
              trailing: Text(e.time.toLocal().toString().split('.').first),
            );
          },
        ))
      ],
    );
  }
}
