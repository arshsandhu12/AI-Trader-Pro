
import 'package:flutter/material.dart';

class JournalTab extends StatelessWidget {
  const JournalTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: const [
        Text("Trade Journal", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text("• In the full version, your executed trades and notes will appear here."),
      ],
    );
  }
}
