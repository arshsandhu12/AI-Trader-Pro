
import 'dart:math';
import '../models/signal.dart';

class SignalEngine {
  // Placeholder ICT/FVG/OB logic that produces deterministic signals without external data.
  // Replace with real OHLC inputs to compute true levels.
  static Future<List<Signal>> generate(String symbol, String tf, {int n=40}) async {
    final seed = symbol.hashCode ^ tf.hashCode;
    final rnd = Random(seed);
    final now = DateTime.now().toUtc();
    final out = <Signal>[];

    for (int i=n;i>=1;i--){
      final t = now.subtract(Duration(minutes: _tfToMin(tf)*i));
      final side = rnd.nextBool() ? "BUY" : "SELL";
      final base = 100 + rnd.nextDouble()*10;
      // emulate FVG/OB-derived levels
      final entry = base + (side=="BUY" ? 0.2 : -0.2);
      final sl = side=="BUY" ? entry - (0.8 + rnd.nextDouble()*0.4) : entry + (0.8 + rnd.nextDouble()*0.4);
      final tp = side=="BUY" ? entry + (1.6 + rnd.nextDouble()*0.6) : entry - (1.6 + rnd.nextDouble()*0.6);
      final score = 60 + rnd.nextDouble()*35; // confidence
      final reason = side=="BUY"
        ? "ICT confluence: Bullish FVG + OB near liquidity. RR≈1:2."
        : "ICT confluence: Bearish FVG + OB sweep. RR≈1:2.";
      out.add(Signal(
        id: "$symbol-$tf-${t.millisecondsSinceEpoch}",
        symbol: symbol,
        timeframe: tf,
        time: t,
        side: side,
        entry: entry,
        sl: sl,
        tp: tp,
        score: score,
        reason: reason,
      ));
    }
    return out;
  }

  static int _tfToMin(String tf){
    switch(tf){
      case "1": return 1;
      case "5": return 5;
      case "15": return 15;
      case "60": return 60;
      case "240": return 240;
      case "D": return 1440;
      default: return 60;
    }
  }
}
