
import 'package:flutter/material.dart';
import '../services/plugin_store.dart';

class PluginsScreen extends StatefulWidget {
  const PluginsScreen({super.key});
  @override
  State<PluginsScreen> createState() => _PluginsScreenState();
}

class _PluginsScreenState extends State<PluginsScreen> {
  List<PluginInfo> list = const [];
  @override
  void initState() {
    super.initState();
    PluginStoreApi.list().then((v)=>setState(()=>list=v));
  }
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: list.length,
      itemBuilder: (_,i){
        final p = list[i];
        return Card(
          child: ListTile(
            title: Text(p.name),
            subtitle: Text("${p.description}\nWin rate: ${p.winRate.toStringAsFixed(1)}%"),
            trailing: ElevatedButton(
              onPressed: (){},
              child: Text(p.installed? "Installed" : "Install"),
            ),
          ),
        );
      },
    );
  }
}
