
class NewsFilter {
  // Stub: normally pull calendar/news. Here we simulate 'low/medium/high' impact windows.
  static String impactNow(String symbol){
    final h = DateTime.now().hour;
    if ([7,8,9,13,14].contains(h)) return "high";
    if ([10,11,12,15].contains(h)) return "medium";
    return "low";
  }
}
