
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/signal.dart';

class SignalStore {
  static Future<void> save(String symbol, String tf, List<Signal> signals) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sig_${symbol}_$tf', jsonEncode(signals.map((e)=>e.toJson()).toList()));
  }
  static Future<List<Signal>> load(String symbol, String tf) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('sig_${symbol}_$tf');
    if (raw==null) return [];
    final list = (jsonDecode(raw) as List).cast<Map<String,dynamic>>();
    return list.map((m)=>Signal.fromJson(m)).toList();
  }
}
