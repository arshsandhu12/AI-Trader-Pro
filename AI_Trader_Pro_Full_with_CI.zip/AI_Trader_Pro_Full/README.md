
# AI Trader Pro (Full Scaffold)

This project includes:
- TradingView WebView chart + AI signals overlay (persistent on device)
- ICT / FVG / Order Block / Order Flow **stubs** (replace with your real logic)
- Strictness filters (Safe / Balanced / Risk)
- Backtester (simulates from saved signals)
- Learning Hub, Journal, Dashboard
- Options helper, News impact meter, Plugin store (UI)
- Auto-Trade toggle (stub)

## Build APK
1) Install Flutter + Android Studio
2) `flutter pub get`
3) `flutter build apk --release`
APK path: `build/app/outputs/flutter-apk/app-release.apk`

> Note: This is a no-keys, offline-friendly scaffold. Plug real OHLC/news/broker APIs as needed.


## Phone-only: get APK without a PC (GitHub Actions)
1. Create a free GitHub account (in the mobile app or browser).
2. Create a new **public repo** and upload all files from this ZIP.
3. Open the repo → **Actions** tab → enable workflows.
4. Run **Build Android APK** workflow (or push a commit).
5. After it finishes, go to **Actions → latest run → Artifacts** and download `ai-trader-pro-debug-apk`.
6. Install `app-debug.apk` on your phone (allow "Install unknown apps").

Optionally use **GitHub Codespaces** or **Gitpod** on your phone browser to run:
```
flutter pub get
flutter build apk --debug
```
and download the APK from the workspace.
