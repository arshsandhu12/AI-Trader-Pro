
class OptionsHelper {
  static Map<String, dynamic> suggest(String symbol, double price, {String bias="long"}){
    final dte = 14; // 2 weeks
    final strike = (price * (bias=="long" ? 1.02 : 0.98));
    return {
      'expiryDays': dte,
      'strike': double.parse(strike.toStringAsFixed(2)),
      'type': bias=="long" ? "CALL" : "PUT",
      'note': "ATM±2% w/ ~14 DTE for liquidity."
    };
  }
}
