
class PluginInfo {
  final String id;
  final String name;
  final String description;
  final double winRate;
  final bool installed;
  const PluginInfo(this.id, this.name, this.description, this.winRate, this.installed);
}

class PluginStoreApi {
  static Future<List<PluginInfo>> list() async {
    return const [
      PluginInfo('ict_core','ICT Core','Core imbalance + OB + FVG confluence', 62.5, true),
      PluginInfo('qtr_theory','Quarterly Theory','Quarterly opens + session bias', 58.3, false),
      PluginInfo('orderflow_plus','Order Flow+','Delta + volume clusters', 60.1, false),
    ];
  }
}
