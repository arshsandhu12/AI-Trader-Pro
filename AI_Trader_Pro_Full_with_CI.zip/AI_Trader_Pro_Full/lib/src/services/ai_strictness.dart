
import '../models/signal.dart';
import '../state/app_state.dart';

class AiStrictness {
  static List<Signal> filter(List<Signal> signals, Strictness s){
    switch(s){
      case Strictness.safe:
        return signals.where((x)=> x.score >= 75).toList();
      case Strictness.balanced:
        return signals.where((x)=> x.score >= 65).toList();
      case Strictness.risk:
        return signals.where((x)=> x.score >= 55).toList();
    }
  }
}
