
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum Mode { day, swing, options }
enum Strictness { safe, balanced, risk }
enum AiApply { off, ask, auto }

class AppState extends ChangeNotifier {
  late SharedPreferences _prefs;
  Mode mode = Mode.day;
  Strictness strictness = Strictness.balanced;
  AiApply aiApply = AiApply.ask;
  bool autoTrade = false;
  bool coachMode = true;
  bool learningHub = true;
  bool tvOverlay = true;
  bool backtesterEnabled = true;
  bool biasAutoUpdate = true;
  bool aiAutoMerge = true;
  bool newsFilter = true;
  bool heatmapEnabled = true;
  bool optionsHelper = true;
  bool pluginStoreEnabled = true;
  bool dashboardEnabled = true;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs.getString('app_state_full_v2');
    if (raw != null) {
      final m = jsonDecode(raw);
      mode = Mode.values[m['mode'] ?? 0];
      strictness = Strictness.values[m['strictness'] ?? 1];
      aiApply = AiApply.values[m['aiApply'] ?? 1];
      autoTrade = m['autoTrade'] ?? false;
      coachMode = m['coachMode'] ?? true;
      learningHub = m['learningHub'] ?? true;
      tvOverlay = m['tvOverlay'] ?? true;
      backtesterEnabled = m['backtesterEnabled'] ?? true;
      biasAutoUpdate = m['biasAutoUpdate'] ?? true;
      aiAutoMerge = m['aiAutoMerge'] ?? true;
      newsFilter = m['newsFilter'] ?? true;
      heatmapEnabled = m['heatmapEnabled'] ?? true;
      optionsHelper = m['optionsHelper'] ?? true;
      pluginStoreEnabled = m['pluginStoreEnabled'] ?? true;
      dashboardEnabled = m['dashboardEnabled'] ?? true;
    }
  }

  Future<void> _persist() async {
    await _prefs.setString('app_state_full_v2', jsonEncode({
      'mode': mode.index,
      'strictness': strictness.index,
      'aiApply': aiApply.index,
      'autoTrade': autoTrade,
      'coachMode': coachMode,
      'learningHub': learningHub,
      'tvOverlay': tvOverlay,
      'backtesterEnabled': backtesterEnabled,
      'biasAutoUpdate': biasAutoUpdate,
      'aiAutoMerge': aiAutoMerge,
      'newsFilter': newsFilter,
      'heatmapEnabled': heatmapEnabled,
      'optionsHelper': optionsHelper,
      'pluginStoreEnabled': pluginStoreEnabled,
      'dashboardEnabled': dashboardEnabled,
    }));
    notifyListeners();
  }

  // setters
  void setMode(Mode v){ mode = v; _persist(); }
  void setStrictness(Strictness v){ strictness = v; _persist(); }
  void setAiApply(AiApply v){ aiApply = v; _persist(); }
  void setAutoTrade(bool v){ autoTrade = v; _persist(); }
  void setCoachMode(bool v){ coachMode = v; _persist(); }
  void setLearningHub(bool v){ learningHub = v; _persist(); }
  void setTvOverlay(bool v){ tvOverlay = v; _persist(); }
  void setBacktester(bool v){ backtesterEnabled = v; _persist(); }
  void setBiasAutoUpdate(bool v){ biasAutoUpdate = v; _persist(); }
  void setAiAutoMerge(bool v){ aiAutoMerge = v; _persist(); }
  void setNewsFilter(bool v){ newsFilter = v; _persist(); }
  void setHeatmap(bool v){ heatmapEnabled = v; _persist(); }
  void setOptionsHelper(bool v){ optionsHelper = v; _persist(); }
  void setPluginStore(bool v){ pluginStoreEnabled = v; _persist(); }
  void setDashboard(bool v){ dashboardEnabled = v; _persist(); }
}
